# Random Android ID Test Module (source)

This is a minimal LSPosed/Xposed **test-project template**. By default it targets only
`com.example.idtest` (an app you own/control), not third-party apps.

It hooks `Settings.Secure.getString(ContentResolver, "android_id")` and returns a
random 16-character hex value for the lifetime of that app process. Restarting the
target process generates a new value.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the APK and enable it in LSPosed, then reboot/restart the test app.

This environment has not built or tested an APK. The generated artifact is source only.
Use only with apps and devices you are authorized to test.


## Automatic APK build with GitHub Actions
1. Create a new GitHub repository and upload all files in this project.
2. Ensure the workflow file `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab and select **Build APK**.
4. Click **Run workflow** (or push to `main`/`master`).
5. When the run finishes, open the run and download the artifact named
   `RandomAndroidIdTestModule-debug`. The APK inside is an unsigned debug build
   suitable for local testing; verify it on your own test device.
