package com.example.randomandroidid;

import android.content.ContentResolver;
import android.provider.Settings;
import java.security.SecureRandom;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class RandomIdHook implements IXposedHookLoadPackage {
    // Restrict this test hook to an app you own or are authorized to test.
    private static final String TARGET_PACKAGE = "com.xhey.xcamera";
    private static final String ANDROID_ID = "android_id";
    private static final String PROCESS_ID = createRandomId();

    private static String createRandomId() {
        byte[] bytes = new byte[8];
        new SecureRandom().nextBytes(bytes);
        StringBuilder sb = new StringBuilder(16);
        for (byte b : bytes) sb.append(String.format("%02x", b & 0xff));
        return sb.toString();
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) return;

        XposedHelpers.findAndHookMethod(
            Settings.Secure.class,
            "getString",
            ContentResolver.class,
            String.class,
            new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (ANDROID_ID.equals(param.args[1])) {
                        param.setResult(PROCESS_ID);
                    }
                }
            }
        );
    }
}
